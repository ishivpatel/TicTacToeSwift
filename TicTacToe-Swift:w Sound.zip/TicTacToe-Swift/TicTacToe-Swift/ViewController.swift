//
//  ViewController.swift
//  TicTacToe-Swift
//
//  Created by Shiv Patel on 10/30/16.
//  Copyright © 2016 Shiv Patel. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var whoseTurn: UILabel!
    
    @IBOutlet weak var resetButton: UIButton!    
    var playerToken: Int = 1
    var Board = [ 0,0,0,0,0,0,0,0,0]
    var array = 0
    var boardsize: Int = 8
    var xscore: Int = 0
    var oscore: Int = 0
    var gameOver = false
    var swishSound: AVAudioPlayer!
    var swordSound: AVAudioPlayer!
    //Boxes
    
    @IBOutlet weak var s1: UIImageView!
    @IBOutlet weak var s2: UIImageView!
    @IBOutlet weak var s3: UIImageView!
    @IBOutlet weak var s4: UIImageView!
    @IBOutlet weak var s5: UIImageView!
    @IBOutlet weak var s6: UIImageView!
    @IBOutlet weak var s7: UIImageView!
    @IBOutlet weak var s8: UIImageView!
    @IBOutlet weak var s9: UIImageView!
    
    @IBOutlet weak var xscorelabel: UILabel!
    @IBOutlet weak var oscorelabel: UILabel!
 
    
    
    @IBAction func newGame(_ sender: Any) {
        resetBoard()
    }

    func resetBoard(){
        
        gameOver = false
        updatescores()
       
        s1.image = nil
        s2.image = nil
        s3.image = nil
        s4.image = nil
        s5.image = nil
        s6.image = nil
        s7.image = nil
        s8.image = nil
        s9.image = nil
        array = 0
        playerToken = 1
        whoseTurn.text = "Player X Starts"
        for i in (0...boardsize) {
            Board[i] = 0
        }
        
    }
    
    func updateState(){
        if(playerToken == 1)
        {
            
            do {
                let path = Bundle.main.path(forResource: "sword.mp3", ofType:nil)!
                let url = URL(fileURLWithPath: path)

                let sound = try AVAudioPlayer(contentsOf: url)
                swordSound = sound
                sound.play()
            } catch {
                // couldn't load file :(
            }
            self.whoseTurn.text = "Player O's Turn";
            let when = DispatchTime.now() + 0.5
            DispatchQueue.main.asyncAfter(deadline: when){
                // Your code
                self.playerToken = 2
                self.computerTurn()
            }
        }
        if (playerToken == 2){
            do {
                let path = Bundle.main.path(forResource: "swish.mp3", ofType:nil)!
                let url = URL(fileURLWithPath: path)
                
                let sound = try AVAudioPlayer(contentsOf: url)
                swishSound = sound
                sound.play()
            } catch {
                // couldn't load file :(
            }
            self.playerToken = 1
            self.whoseTurn.text = "Player X's Turn"
            
        }
    }
    
    func updatescores(){
        self.xscorelabel.text = "X's Score: \(xscore)"
        self.oscorelabel.text = "O's Score: \(oscore)"
    }
    
    func updatePlayer() {
        if(gameOver == false){
        
        updateState()
        if(checkForWin() == 1){
            gameOver = true
            print(xscore)
            print("--")
            xscore += 1
            oscore += 1
           
            let alert = UIAlertController(title: "Game Over", message: "It Was a Tie", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "New Game", style: UIAlertActionStyle.default, handler: { ACTION in
                self.resetBoard()}))
            self.present(alert, animated: true, completion: nil)
        }
        
        else if(checkForWin() == 2){
            gameOver = true
            xscore += 1
            let alertController = UIAlertController(title: "Game Over", message: "Player X Won", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "New Game", style: UIAlertActionStyle.default) { (result : UIAlertAction) -> Void in
                self.resetBoard()
            }
            
            alertController.addAction(okAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
         else if (checkForWin() == 3){
            gameOver = true
            oscore += 1
            let alert = UIAlertController(title: "Game Over", message: "Player O Won", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "New Game", style: UIAlertActionStyle.default, handler: { ACTION in
                self.resetBoard()}))
            self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    func checkForTie() -> Int{
        if(Board[0] != 0 && Board[1] != 0 && Board[2] != 0 && Board[3] != 0
        && Board[4] != 0 && Board[5] != 0 && Board[6] != 0 && Board[7] != 0
        && Board[8] != 0){
            return 1
        }
        return 0
    }
    
    func checkForWin() -> Int {
        
        //Horizontal for X
        if((Board[0] == Board[1] && Board[1] == Board[2] && Board[0] == 1 )
            || (Board[3] == Board[4] && Board[4] == Board[5] && Board[3] == 1)
            || (Board[6] == Board[7] && Board[7] == Board[8] && Board[6] == 1)){
            return 2
        }
       
        //Horizontal for O
        else if((Board[0] == Board[1] && Board[1] == Board[2] && Board[0] == 2)
            || (Board[3] == Board[4] && Board[4] == Board[5] && Board[3] == 2)
            || (Board[6] == Board[7] && Board[7] == Board[8] && Board[6] == 2)){
            return 3
        }
        
        //Vertical for X
        else if((Board[0] == Board[3] && Board[3] == Board[6] && Board[0] == 1)
            || (Board[1] == Board[4] && Board[4] == Board[7] && Board[1] == 1)
            || (Board[2] == Board[5] && Board[5] == Board[8] && Board[2] == 1)){
            return 2
        }
        
        //Vertical for O
       else if((Board[0] == Board[3] && Board[3] == Board[6] && Board[0] == 2)
            || (Board[1] == Board[4] && Board[4] == Board[7] && Board[1] == 2)
            || (Board[2] == Board[5] && Board[5] == Board[8] && Board[2] == 2)){
            return 3
        }
        
        //Diagnol
        else if((Board[0] == Board[4] && Board[4] == Board[8] && Board[0] == 1)
            || (Board[2] == Board[4] && Board[4] == Board[6] && Board[2] == 1)){
            return 2
        }
        
        //for O
        else if((Board[0] == Board[4] && Board[4] == Board[8] && Board[0] == 2)
            || (Board[2] == Board[4] && Board[4] == Board[6] && Board[2] == 2))
        {
            return 3
        }
        if(checkForTie() == 1){
            return 1
        }
        
     return 0
    }
    
    func maketurn(i: Int){
        switch(i){
        case 0: imgclicked1()
        break;
        case 1: imgclicked2()
        break;
        case 2: imgclicked3()
        break;
        case 3: imgclicked4()
        break;
        case 4: imgclicked5()
        break;
        case 5: imgclicked6()
        break;
        case 6: imgclicked7()
        break;
        case 7: imgclicked8()
        break;
        case 8: imgclicked9()
        break;
        default: break
            
        }
    }
    
    func computerTurn(){
        if(array <= 3){
        array = array + 1
        var status = 0
        // First see if there's a move O can make to win
        for i in 0...boardsize {
            if(Board[i] != 1 && Board[i] != 2){
            
                Board[i] = 2
                if(checkForWin() == 3){
                    maketurn(i: i)
                    status = 1
                    break
                }
                Board[i] = 1
                if(checkForWin() == 2){
                    Board[i] = 2
                    maketurn(i: i)
                    status = 1
                    break
                }
                
                Board[i] = 0
            }
        }
        
        if(status == 0){
        var temp = Int(arc4random_uniform(UInt32(boardsize)))
        while(Board[temp] == 1 || Board[temp] == 2){
           
            temp = Int(arc4random_uniform(UInt32(boardsize)))
        }
        Board[temp] = 2
        maketurn(i: temp)
        }
    }
}
    
    func imgclicked1(){
        if( s1.image == nil){
            if(playerToken == 1){
                s1.image = #imageLiteral(resourceName: "x_img")
                Board[0] = 1
            }
            else {
                s1.image = #imageLiteral(resourceName: "o_img")
                Board[0] = 2
            }
            updatePlayer()
        }
    }
    
    func imgclicked2(){
        if( s2.image == nil){
            if(playerToken == 1){
                s2.image = #imageLiteral(resourceName: "x_img")
                Board[1] = 1
            }
            else {
                s2.image = #imageLiteral(resourceName: "o_img")
                Board[1] = 2
            }
             updatePlayer()
        }
    }
    
    func imgclicked3(){
         if( s3.image == nil){
            if(playerToken == 1){
                s3.image = #imageLiteral(resourceName: "x_img")
                Board[2] = 1
            }
            else
            {
                s3.image = #imageLiteral(resourceName: "o_img")
                Board[2] = 2
            }
        updatePlayer()
        }
    }
    
    func imgclicked4(){
         if( s4.image == nil){
            if(playerToken == 1){
                s4.image = #imageLiteral(resourceName: "x_img")
                Board[3] = 1
            }
            else {
                s4.image = #imageLiteral(resourceName: "o_img")
                Board[3] = 2
            }
        updatePlayer()
        }
    }
    
    func imgclicked5(){
         if( s5.image == nil){
            if(playerToken == 1){
                s5.image = #imageLiteral(resourceName: "x_img")
                Board[4] = 1
            }
            else {
                s5.image = #imageLiteral(resourceName: "o_img")
                Board[4] = 2
               
            }
       updatePlayer()
        }
    }
    
    func imgclicked6(){
         if( s6.image == nil){
            if(playerToken == 1){
                s6.image = #imageLiteral(resourceName: "x_img")
                Board[5] = 1
            }
            else {
                s6.image = #imageLiteral(resourceName: "o_img")
                Board[5] = 2
                
            }
        updatePlayer()
        }
    }
    
    func imgclicked7(){
         if( s7.image == nil){
            if(playerToken == 1){
                s7.image = #imageLiteral(resourceName: "x_img")
                Board[6] = 1
            }
           else {
                s7.image = #imageLiteral(resourceName: "o_img")
                Board[6] = 2
            }
        updatePlayer()
        }
    }
    
    func imgclicked8(){
         if( s8.image == nil){
            if(playerToken == 1){
                s8.image = #imageLiteral(resourceName: "x_img")
                Board[7] = 1
            }
           else {
                s8.image = #imageLiteral(resourceName: "o_img")
                Board[7] = 2
            }
         updatePlayer()
        }
    }
    
    func imgclicked9(){
         if( s9.image == nil){
            if(playerToken == 1){
                s9.image = #imageLiteral(resourceName: "x_img")
                Board[8] = 1
            }
            else {
                s9.image = #imageLiteral(resourceName: "o_img")
                Board[8] = 2
            }
            updatePlayer()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.whoseTurn.text = "Player X Starts"
        
        let TapGesture1 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked1))
        TapGesture1.numberOfTapsRequired = 1
        s1.addGestureRecognizer(TapGesture1)
        
        let TapGesture2 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked2))
        TapGesture2.numberOfTapsRequired = 1
        s2.addGestureRecognizer(TapGesture2)
        
        let TapGesture3 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked3))
        TapGesture3.numberOfTapsRequired = 1
        s3.addGestureRecognizer(TapGesture3)
        
        
        let TapGesture4 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked4))
        TapGesture4.numberOfTapsRequired = 1
        s4.addGestureRecognizer(TapGesture4)
        
        let TapGesture5 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked5))
        TapGesture5.numberOfTapsRequired = 1
        s5.addGestureRecognizer(TapGesture5)
        
        let TapGesture6 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked6))
        TapGesture6.numberOfTapsRequired = 1
        s6.addGestureRecognizer(TapGesture6)
        
       
        let TapGesture7 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked7))
        TapGesture7.numberOfTapsRequired = 1
        s7.addGestureRecognizer(TapGesture7)
        
        let TapGesture8 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked8))
        TapGesture8.numberOfTapsRequired = 1
        s8.addGestureRecognizer(TapGesture8)
        
        let TapGesture9 = UITapGestureRecognizer(target: self, action: #selector(ViewController.imgclicked9))
        TapGesture9.numberOfTapsRequired = 1
        s9.addGestureRecognizer(TapGesture9)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

